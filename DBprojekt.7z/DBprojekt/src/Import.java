public class Import {
    private static DataBase db = new DataBase();
//    public static boolean importFromCSV(String table, String delimiter,
//                                      String path) {
//
//        //COPY table_namee FROM locationn DELIMITER delimiterr CSV HEADER;
//    }
}
